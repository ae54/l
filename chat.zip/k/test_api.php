<?php
// Test script for API endpoints
echo "API Test Script\n";
echo "==============\n\n";

// Helper function to make API requests
function testEndpoint($action, $method = 'GET', $data = null) {
    echo "Testing $method $action...\n";
    
    $ch = curl_init("http://localhost:8000/api.php?action=$action");
    
    $options = [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HEADER => false,
        CURLOPT_COOKIEFILE => "cookie.txt",
        CURLOPT_COOKIEJAR => "cookie.txt",
    ];
    
    if ($method === 'POST') {
        $options[CURLOPT_POST] = true;
        if ($data) {
            $options[CURLOPT_POSTFIELDS] = json_encode($data);
        }
    }
    
    $options[CURLOPT_HTTPHEADER] = [
        'Content-Type: application/json',
        'Accept: application/json'
    ];
    
    curl_setopt_array($ch, $options);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    
    curl_close($ch);
    
    if ($error) {
        echo "Error: $error\n";
        return null;
    }
    
    echo "Status: $httpCode\n";
    $result = json_decode($response, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        echo "Error parsing JSON: " . json_last_error_msg() . "\n";
        echo "Raw response: $response\n";
        return null;
    }
    
    echo "Response: " . print_r($result, true) . "\n";
    return $result;
}

// 1. Test Register
echo "\n[1] Testing Registration\n";
$registerResult = testEndpoint('register', 'POST', [
    'username' => 'testuser' . time(),
    'email' => 'test' . time() . '@example.com',
    'password' => '123456'
]);

// 2. Test Login
echo "\n[2] Testing Login\n";
if ($registerResult && $registerResult['success']) {
    $loginResult = testEndpoint('login', 'POST', [
        'username' => $registerResult['user']['username'],
        'password' => '123456'
    ]);
} else {
    // If registration failed, try with a known user
    $loginResult = testEndpoint('login', 'POST', [
        'username' => 'testuser',
        'password' => '123456'
    ]);
}

// 3. Test Check Auth
echo "\n[3] Testing Check Auth\n";
$authResult = testEndpoint('checkAuth', 'GET');

// 4. Test Search Users
echo "\n[4] Testing Search Users\n";
$searchResult = testEndpoint('searchUsers', 'GET', ['query' => 'test']);

// 5. Test Create Chat
echo "\n[5] Testing Create Chat\n";
if ($searchResult && $searchResult['success'] && !empty($searchResult['users'])) {
    $otherUserId = $searchResult['users'][0]['id'];
    $createChatResult = testEndpoint('createChat', 'POST', [
        'userId' => $otherUserId
    ]);
} else {
    echo "Couldn't find users to create chat with\n";
}

// 6. Test Get Chats
echo "\n[6] Testing Get Chats\n";
$chatsResult = testEndpoint('getChats', 'GET');

// 7. Test Get Messages
echo "\n[7] Testing Get Messages\n";
if ($chatsResult && $chatsResult['success'] && !empty($chatsResult['chats'])) {
    $chatId = $chatsResult['chats'][0]['id'];
    $messagesResult = testEndpoint('getMessages', 'GET', [
        'chatId' => $chatId
    ]);
}

// 8. Test Send Message
echo "\n[8] Testing Send Message\n";
if (isset($chatId)) {
    $sendMessageResult = testEndpoint('sendMessage', 'POST', [
        'chatId' => $chatId,
        'content' => 'Test message ' . time()
    ]);
}

// 9. Test Delete Message
echo "\n[9] Testing Delete Message\n";
if (isset($sendMessageResult) && $sendMessageResult['success']) {
    $messageId = $sendMessageResult['message']['id'];
    $deleteMessageResult = testEndpoint('deleteMessage', 'POST', [
        'messageId' => $messageId
    ]);
}

// 10. Test Get User
echo "\n[10] Testing Get User\n";
if (isset($otherUserId)) {
    $getUserResult = testEndpoint('getUser', 'GET', [
        'userId' => $otherUserId
    ]);
}

// 11. Test Logout
echo "\n[11] Testing Logout\n";
$logoutResult = testEndpoint('logout', 'GET');

echo "\nAPI Testing Completed\n";
?>
