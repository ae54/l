document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const loginContainer = document.getElementById('loginContainer');
    const dashboardContainer = document.getElementById('dashboardContainer');
    const loginForm = document.getElementById('loginForm');
    const loginError = document.getElementById('loginError');
    const adminUsername = document.getElementById('adminUsername');
    const logoutBtn = document.getElementById('logoutBtn');
    
    // Table Bodies
    const usersTableBody = document.getElementById('usersTableBody');
    const chatsTableBody = document.getElementById('chatsTableBody');
    const messagesTableBody = document.getElementById('messagesTableBody');
    
    // Dashboard Counters
    const totalUsersCount = document.getElementById('totalUsersCount');
    const totalChatsCount = document.getElementById('totalChatsCount');
    const totalMessagesCount = document.getElementById('totalMessagesCount');
    const userCount = document.getElementById('userCount');
    const chatCount = document.getElementById('chatCount');
    const messageCount = document.getElementById('messageCount');
    const dashboardUserCount = document.getElementById('dashboardUserCount');
    const dashboardChatCount = document.getElementById('dashboardChatCount');
    const dashboardMessageCount = document.getElementById('dashboardMessageCount');
    
    // Search Inputs
    const userSearchInput = document.getElementById('userSearchInput');
    const chatSearchInput = document.getElementById('chatSearchInput');
    const messageSearchInput = document.getElementById('messageSearchInput');
    
    // Modal Elements
    const userModal = new bootstrap.Modal(document.getElementById('userModal'));
    const chatModal = new bootstrap.Modal(document.getElementById('chatModal'));
    const messageModal = new bootstrap.Modal(document.getElementById('messageModal'));
    
    // User modal elements
    const userModalAvatar = document.getElementById('userModalAvatar');
    const userModalUsername = document.getElementById('userModalUsername');
    const userModalName = document.getElementById('userModalName');
    const userModalEmail = document.getElementById('userModalEmail');
    const userModalCreated = document.getElementById('userModalCreated');
    const userModalBio = document.getElementById('userModalBio');
    const userModalDeleteBtn = document.getElementById('userModalDeleteBtn');
    
    // Chat modal elements
    const chatModalId = document.getElementById('chatModalId');
    const chatModalCreated = document.getElementById('chatModalCreated');
    const chatModalUser1Avatar = document.getElementById('chatModalUser1Avatar');
    const chatModalUser1Username = document.getElementById('chatModalUser1Username');
    const chatModalUser1Name = document.getElementById('chatModalUser1Name');
    const chatModalUser2Avatar = document.getElementById('chatModalUser2Avatar');
    const chatModalUser2Username = document.getElementById('chatModalUser2Username');
    const chatModalUser2Name = document.getElementById('chatModalUser2Name');
    const chatModalDeleteBtn = document.getElementById('chatModalDeleteBtn');
    
    // Message modal elements
    const messageModalId = document.getElementById('messageModalId');
    const messageModalChatId = document.getElementById('messageModalChatId');
    const messageModalSenderId = document.getElementById('messageModalSenderId');
    const messageModalTimestamp = document.getElementById('messageModalTimestamp');
    const messageModalRead = document.getElementById('messageModalRead');
    const messageModalContent = document.getElementById('messageModalContent');
    const messageModalDeleteBtn = document.getElementById('messageModalDeleteBtn');
    
    // API Base URL
    const API_URL = 'api.php';
    
    // Data Storage
    let users = [];
    let chats = [];
    let messages = [];
    
    // Check if the user is already logged in
    checkAuth();
    
    // Event Listeners
    loginForm.addEventListener('submit', handleLogin);
    logoutBtn.addEventListener('click', handleLogout);
    userSearchInput.addEventListener('input', filterUsers);
    chatSearchInput.addEventListener('input', filterChats);
    messageSearchInput.addEventListener('input', filterMessages);
    userModalDeleteBtn.addEventListener('click', deleteUserFromModal);
    chatModalDeleteBtn.addEventListener('click', deleteChatFromModal);
    messageModalDeleteBtn.addEventListener('click', deleteMessageFromModal);
    
    // Periodically refresh data (every 30 seconds)
    setInterval(refreshData, 30000);
    
    // Functions
    function checkAuth() {
        fetch(`${API_URL}?action=checkAuth`)
            .then(response => response.json())
            .then(data => {
                if (data.success && data.user && data.user.isAdmin) {
                    showDashboard();
                    adminUsername.textContent = data.user.username;
                    loadAllData();
                } else {
                    showLogin();
                }
            })
            .catch(error => {
                console.error('Auth check error:', error);
                showLogin();
            });
    }
    
    function handleLogin(e) {
        e.preventDefault();
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        
        fetch(`${API_URL}?action=login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                username,
                password
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                if (data.user.isAdmin) {
                    showDashboard();
                    adminUsername.textContent = data.user.username;
                    loadAllData();
                } else {
                    loginError.textContent = 'Admin access required';
                    loginError.style.display = 'block';
                }
            } else {
                loginError.textContent = data.error || 'Invalid credentials';
                loginError.style.display = 'block';
            }
        })
        .catch(error => {
            console.error('Login error:', error);
            loginError.textContent = 'Network error. Please try again.';
            loginError.style.display = 'block';
        });
    }
    
    function handleLogout() {
        fetch(`${API_URL}?action=logout`)
            .then(() => {
                showLogin();
            })
            .catch(error => console.error('Logout error:', error));
    }
    
    function showLogin() {
        loginContainer.style.display = 'block';
        dashboardContainer.style.display = 'none';
        loginError.style.display = 'none';
        document.getElementById('username').value = '';
        document.getElementById('password').value = '';
    }
    
    function showDashboard() {
        loginContainer.style.display = 'none';
        dashboardContainer.style.display = 'block';
    }
    
    function loadAllData() {
        Promise.all([
            fetch(`${API_URL}?action=admin_get_all_users`).then(response => response.json()),
            fetch(`${API_URL}?action=admin_get_all_chats`).then(response => response.json()),
            fetch(`${API_URL}?action=admin_get_all_messages`).then(response => response.json())
        ])
        .then(([usersData, chatsData, messagesData]) => {
            if (usersData.success) {
                users = usersData.users;
                renderUsers(users);
                updateUserCounters(users.length);
            }
            
            if (chatsData.success) {
                chats = chatsData.chats;
                renderChats(chats);
                updateChatCounters(chats.length);
            }
            
            if (messagesData.success) {
                messages = messagesData.messages;
                renderMessages(messages);
                updateMessageCounters(messages.length);
            }
        })
        .catch(error => console.error('Data loading error:', error));
    }
    
    function refreshData() {
        loadAllData();
    }
    
    function renderUsers(usersData) {
        usersTableBody.innerHTML = '';
        
        usersData.forEach(user => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${user.id.substring(0, 8)}...</td>
                <td><img src="${user.avatar}" alt="${user.username}" class="rounded-circle" width="30" height="30"></td>
                <td>${user.username}</td>
                <td>${user.name || '-'}</td>
                <td>${user.email}</td>
                <td>${user.created_at}</td>
                <td>
                    <i class="fas fa-eye action-icon view" title="View User" data-user-id="${user.id}"></i>
                    <i class="fas fa-trash action-icon delete" title="Delete User" data-user-id="${user.id}"></i>
                </td>
            `;
            
            usersTableBody.appendChild(row);
        });
        
        // Add event listeners
        document.querySelectorAll('#usersTableBody .fa-eye').forEach(icon => {
            icon.addEventListener('click', () => {
                const userId = icon.getAttribute('data-user-id');
                showUserDetails(userId);
            });
        });
        
        document.querySelectorAll('#usersTableBody .fa-trash').forEach(icon => {
            icon.addEventListener('click', () => {
                const userId = icon.getAttribute('data-user-id');
                if (confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
                    deleteUser(userId);
                }
            });
        });
    }
    
    function renderChats(chatsData) {
        chatsTableBody.innerHTML = '';
        
        chatsData.forEach(chat => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${chat.id.substring(0, 8)}...</td>
                <td>${chat.user1.username}</td>
                <td>${chat.user2.username}</td>
                <td>${chat.created_at}</td>
                <td>
                    <i class="fas fa-eye action-icon view" title="View Chat" data-chat-id="${chat.id}"></i>
                    <i class="fas fa-trash action-icon delete" title="Delete Chat" data-chat-id="${chat.id}"></i>
                </td>
            `;
            
            chatsTableBody.appendChild(row);
        });
        
        // Add event listeners
        document.querySelectorAll('#chatsTableBody .fa-eye').forEach(icon => {
            icon.addEventListener('click', () => {
                const chatId = icon.getAttribute('data-chat-id');
                showChatDetails(chatId);
            });
        });
        
        document.querySelectorAll('#chatsTableBody .fa-trash').forEach(icon => {
            icon.addEventListener('click', () => {
                const chatId = icon.getAttribute('data-chat-id');
                if (confirm('Are you sure you want to delete this chat? This action cannot be undone.')) {
                    deleteChat(chatId);
                }
            });
        });
    }
    
    function renderMessages(messagesData) {
        messagesTableBody.innerHTML = '';
        
        messagesData.forEach(message => {
            const row = document.createElement('tr');
            
            // Find sender info
            let senderUsername = 'Unknown';
            const senderId = message.senderId;
            
            // Look for the sender in the chats
            chats.forEach(chat => {
                if (chat.user1.id === senderId) {
                    senderUsername = chat.user1.username;
                } else if (chat.user2.id === senderId) {
                    senderUsername = chat.user2.username;
                }
            });
            
            row.innerHTML = `
                <td>${message.id.substring(0, 8)}...</td>
                <td>${message.chatId.substring(0, 8)}...</td>
                <td>${senderUsername}</td>
                <td class="chat-preview">${message.content}</td>
                <td>${message.timestamp}</td>
                <td>${message.read ? '<span class="badge bg-success">Yes</span>' : '<span class="badge bg-warning">No</span>'}</td>
                <td>
                    <i class="fas fa-eye action-icon view" title="View Message" data-message-id="${message.id}"></i>
                    <i class="fas fa-trash action-icon delete" title="Delete Message" data-message-id="${message.id}"></i>
                </td>
            `;
            
            messagesTableBody.appendChild(row);
        });
        
        // Add event listeners
        document.querySelectorAll('#messagesTableBody .fa-eye').forEach(icon => {
            icon.addEventListener('click', () => {
                const messageId = icon.getAttribute('data-message-id');
                showMessageDetails(messageId);
            });
        });
        
        document.querySelectorAll('#messagesTableBody .fa-trash').forEach(icon => {
            icon.addEventListener('click', () => {
                const messageId = icon.getAttribute('data-message-id');
                if (confirm('Are you sure you want to delete this message? This action cannot be undone.')) {
                    deleteMessage(messageId);
                }
            });
        });
    }
    
    function showUserDetails(userId) {
        const user = users.find(u => u.id === userId);
        if (!user) return;
        
        userModalAvatar.src = user.avatar;
        userModalUsername.textContent = user.username;
        userModalName.textContent = user.name || '-';
        userModalEmail.textContent = user.email;
        userModalCreated.textContent = user.created_at;
        userModalBio.textContent = user.bio || 'No bio provided';
        userModalDeleteBtn.setAttribute('data-user-id', user.id);
        
        userModal.show();
    }
    
    function showChatDetails(chatId) {
        const chat = chats.find(c => c.id === chatId);
        if (!chat) return;
        
        chatModalId.textContent = chat.id;
        chatModalCreated.textContent = chat.created_at;
        
        chatModalUser1Avatar.src = chat.user1.avatar;
        chatModalUser1Username.textContent = chat.user1.username;
        chatModalUser1Name.textContent = chat.user1.name || '-';
        
        chatModalUser2Avatar.src = chat.user2.avatar;
        chatModalUser2Username.textContent = chat.user2.username;
        chatModalUser2Name.textContent = chat.user2.name || '-';
        
        chatModalDeleteBtn.setAttribute('data-chat-id', chat.id);
        
        chatModal.show();
    }
    
    function showMessageDetails(messageId) {
        const message = messages.find(m => m.id === messageId);
        if (!message) return;
        
        messageModalId.textContent = message.id;
        messageModalChatId.textContent = message.chatId;
        messageModalSenderId.textContent = message.senderId;
        messageModalTimestamp.textContent = message.timestamp;
        messageModalRead.textContent = message.read ? 'Yes' : 'No';
        messageModalContent.textContent = message.content;
        messageModalDeleteBtn.setAttribute('data-message-id', message.id);
        
        messageModal.show();
    }
    
    function deleteUser(userId) {
        fetch(`${API_URL}?action=admin_delete_user&userId=${userId}`)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Remove from local data
                    users = users.filter(u => u.id !== userId);
                    renderUsers(users);
                    updateUserCounters(users.length);
                    
                    // Refresh chats and messages as they might be affected
                    fetch(`${API_URL}?action=admin_get_all_chats`)
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                chats = data.chats;
                                renderChats(chats);
                                updateChatCounters(chats.length);
                            }
                        });
                    
                    fetch(`${API_URL}?action=admin_get_all_messages`)
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                messages = data.messages;
                                renderMessages(messages);
                                updateMessageCounters(messages.length);
                            }
                        });
                    
                    alert('User deleted successfully');
                } else {
                    alert(`Error: ${data.error || 'Unknown error'}`);
                }
            })
            .catch(error => {
                console.error('Delete user error:', error);
                alert('Network error occurred while deleting user');
            });
    }
    
    function deleteUserFromModal() {
        const userId = userModalDeleteBtn.getAttribute('data-user-id');
        if (confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
            userModal.hide();
            deleteUser(userId);
        }
    }
    
    function deleteChat(chatId) {
        fetch(`${API_URL}?action=admin_delete_chat&chatId=${chatId}`)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Remove from local data
                    chats = chats.filter(c => c.id !== chatId);
                    renderChats(chats);
                    updateChatCounters(chats.length);
                    
                    // Refresh messages as they might be affected
                    fetch(`${API_URL}?action=admin_get_all_messages`)
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                messages = data.messages;
                                renderMessages(messages);
                                updateMessageCounters(messages.length);
                            }
                        });
                    
                    alert('Chat deleted successfully');
                } else {
                    alert(`Error: ${data.error || 'Unknown error'}`);
                }
            })
            .catch(error => {
                console.error('Delete chat error:', error);
                alert('Network error occurred while deleting chat');
            });
    }
    
    function deleteChatFromModal() {
        const chatId = chatModalDeleteBtn.getAttribute('data-chat-id');
        if (confirm('Are you sure you want to delete this chat? This action cannot be undone.')) {
            chatModal.hide();
            deleteChat(chatId);
        }
    }
    
    function deleteMessage(messageId) {
        fetch(`${API_URL}?action=admin_delete_message&messageId=${messageId}`)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Remove from local data
                    messages = messages.filter(m => m.id !== messageId);
                    renderMessages(messages);
                    updateMessageCounters(messages.length);
                    alert('Message deleted successfully');
                } else {
                    alert(`Error: ${data.error || 'Unknown error'}`);
                }
            })
            .catch(error => {
                console.error('Delete message error:', error);
                alert('Network error occurred while deleting message');
            });
    }
    
    function deleteMessageFromModal() {
        const messageId = messageModalDeleteBtn.getAttribute('data-message-id');
        if (confirm('Are you sure you want to delete this message? This action cannot be undone.')) {
            messageModal.hide();
            deleteMessage(messageId);
        }
    }
    
    function filterUsers() {
        const query = userSearchInput.value.toLowerCase();
        const filteredUsers = users.filter(user => 
            user.username.toLowerCase().includes(query) || 
            user.name?.toLowerCase().includes(query) || 
            user.email.toLowerCase().includes(query)
        );
        
        renderUsers(filteredUsers);
    }
    
    function filterChats() {
        const query = chatSearchInput.value.toLowerCase();
        const filteredChats = chats.filter(chat => 
            chat.user1.username.toLowerCase().includes(query) || 
            chat.user2.username.toLowerCase().includes(query) ||
            chat.id.toLowerCase().includes(query)
        );
        
        renderChats(filteredChats);
    }
    
    function filterMessages() {
        const query = messageSearchInput.value.toLowerCase();
        const filteredMessages = messages.filter(message => 
            message.content.toLowerCase().includes(query) || 
            message.chatId.toLowerCase().includes(query) ||
            message.senderId.toLowerCase().includes(query)
        );
        
        renderMessages(filteredMessages);
    }
    
    function updateUserCounters(count) {
        totalUsersCount.textContent = count;
        userCount.textContent = count;
        dashboardUserCount.textContent = count;
    }
    
    function updateChatCounters(count) {
        totalChatsCount.textContent = count;
        chatCount.textContent = count;
        dashboardChatCount.textContent = count;
    }
    
    function updateMessageCounters(count) {
        totalMessagesCount.textContent = count;
        messageCount.textContent = count;
        dashboardMessageCount.textContent = count;
    }
});
