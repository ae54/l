// Global variables
let currentUser = null;
let currentChat = null;
let isTyping = false;
let typingTimeout = null;
let lastTypingStatus = {};
let pollingInterval = null;

// API Functions
async function apiRequest(action, method = 'GET', data = null) {
    const options = {
        method,
        headers: {
            'Content-Type': 'application/json'
        },
        credentials: 'include'
    };

    if (data && method !== 'GET') {
        options.body = JSON.stringify(data);
    }

    try {
        const url = `api.php?action=${action}${method === 'GET' && data ? `&${new URLSearchParams(data).toString()}` : ''}`;
        const response = await fetch(url, options);
        const result = await response.json();

        if (!result.success && result.error === 'Not logged in') {
            stopPolling();
            showAuthForms();
            return null;
        }

        return result;
    } catch (error) {
        console.error('API Error:', error);
        return { success: false, error: 'Network error' };
    }
}

// Authentication
async function login(username, password) {
    const result = await apiRequest('login', 'POST', { username, password });
    if (result.success) {
        currentUser = result.user;
        // Reload the page to show new content
        window.location.reload();
    } else {
        showError('login-error', result.error);
    }
}

async function register(username, name, email, password) {
    const result = await apiRequest('register', 'POST', { username, name, email, password });
    if (result.success) {
        currentUser = result.user;
        // Reload the page to show new content
        window.location.reload();
    } else {
        showError('register-error', result.error || 'Registration failed');
    }
    return result;
}

async function logout() {
    await apiRequest('logout', 'POST');
    stopPolling();
    currentUser = null;
    currentChat = null;
    showAuthForms();
}

// User Search
async function searchUsers(query) {
    if (!query.trim()) {
        document.querySelector('.user-results').innerHTML = '';
        return;
    }

    const result = await apiRequest('searchUsers', 'GET', { query: query.trim() });
    const userResults = document.querySelector('.user-results');
    userResults.innerHTML = '';

    if (!result || !result.success) {
        userResults.innerHTML = `<div class="no-results">${result?.error || 'Failed to search users'}</div>`;
        return;
    }

    if (result.users.length === 0) {
        userResults.innerHTML = '<div class="no-results">No users found</div>';
        return;
    }

    result.users.forEach(user => {
        const userElement = document.createElement('div');
        userElement.className = 'user-result';
        userElement.innerHTML = `
            <img src="${user.avatar}" alt="${user.username}" class="avatar">
            <span>${user.username}</span>
            <button onclick="createChat('${user.id}')">Chat</button>
        `;
        userResults.appendChild(userElement);
    });
}

// Chat Management
async function createChat(userId) {
    const result = await apiRequest('createChat', 'POST', { userId });
    if (result && result.success) {
        hideAddUserModal();
        await loadChats();
        openChat(result.chat.id, result.chat.user1_id === currentUser.id ? result.chat.user2 : result.chat.user1);
    }
}

async function loadChats() {
    const result = await apiRequest('getChats');
    if (result && result.success) {
        // Get all messages to find last messages and unread counts
        const messagesResult = await apiRequest('getAllMessages'); 
        let chatMessages = {};
        let unreadCounts = {};
        
        if (messagesResult && messagesResult.success) {
            // Group messages by chat
            messagesResult.messages.forEach(message => {
                if (!chatMessages[message.chatId]) {
                    chatMessages[message.chatId] = [];
                }
                chatMessages[message.chatId].push(message);
                
                // Count unread messages
                if (!message.read && message.senderId !== currentUser.id) {
                    unreadCounts[message.chatId] = (unreadCounts[message.chatId] || 0) + 1;
                }
            });
            
            // Sort messages by timestamp
            Object.keys(chatMessages).forEach(chatId => {
                chatMessages[chatId].sort((a, b) => 
                    new Date(b.timestamp) - new Date(a.timestamp)
                );
            });
        }
        
        displayChats(result.chats, chatMessages, unreadCounts);
    }
}

async function loadMessages(chatId) {
    if (!chatId) return;
    
    const result = await apiRequest('getMessages', 'GET', { chatId });
    if (result && result.success) {
        displayMessages(result.messages);
        // After loading messages, reload chats to update unread counts
        loadChats();
    }
}

// UI Functions
function showAuthForms() {
    document.querySelector('.auth-container').classList.remove('hidden');
    document.querySelector('.chat-container').classList.add('hidden');
    document.getElementById('loginForm').reset();
    document.getElementById('registerForm').reset();
    document.getElementById('login-error').style.display = 'none';
    document.getElementById('register-error').style.display = 'none';
}

function showChatInterface() {
    document.querySelector('.auth-container').classList.add('hidden');
    document.querySelector('.chat-container').classList.remove('hidden');
    document.getElementById('userAvatar').src = currentUser.avatar;
    document.getElementById('userName').textContent = currentUser.username;
}

function showError(elementId, message) {
    const errorElement = document.getElementById(elementId);
    errorElement.textContent = message;
    errorElement.style.display = 'block';
    setTimeout(() => {
        errorElement.style.display = 'none';
    }, 3000);
}

function displayChats(chats, chatMessages, unreadCounts) {
    const chatList = document.querySelector('.chat-list');
    chatList.innerHTML = '';

    chats.forEach(chat => {
        const otherUser = chat.user1_id === currentUser.id ? chat.user2 : chat.user1;
        const chatElement = document.createElement('div');
        const isActive = currentChat && chat.id === currentChat;
        const unreadCount = unreadCounts[chat.id] || 0;
        const lastMessage = chatMessages[chat.id] && chatMessages[chat.id].length > 0 
            ? chatMessages[chat.id][0] : null;
        
        // Set class based on unread status and active state
        chatElement.className = `chat-item${isActive ? ' active' : ''}${unreadCount > 0 ? ' unread' : ''}`;
        chatElement.onclick = () => openChat(chat.id, otherUser);
        
        // Create the last message preview
        let lastMessagePreview = '';
        if (lastMessage) {
            const isSentByMe = lastMessage.senderId === currentUser.id;
            const preview = lastMessage.content.length > 25 
                ? lastMessage.content.substring(0, 25) + '...' 
                : lastMessage.content;
            lastMessagePreview = `
                <div class="last-message">
                    ${isSentByMe ? 'You: ' : ''}${preview}
                </div>
            `;
        }
        
        chatElement.innerHTML = `
            <img src="${otherUser.avatar}" alt="${otherUser.username}" class="avatar">
            <div class="chat-item-info">
                <div class="chat-item-name">${otherUser.name || otherUser.username}</div>
                ${lastMessagePreview}
            </div>
            ${unreadCount > 0 ? `<span class="unread-count">${unreadCount}</span>` : ''}
        `;
        
        chatList.appendChild(chatElement);
    });
}

function displayMessages(messages) {
    const messagesList = document.querySelector('.messages-list');
    messagesList.innerHTML = '';
    
    // Sort messages by timestamp (oldest first)
    messages.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));

    messages.forEach(message => {
        const isOwn = message.senderId === currentUser.id;
        const messageElement = document.createElement('div');
        messageElement.className = `message ${isOwn ? 'sent' : 'received'}`;
        
        // Format timestamp
        const messageDate = new Date(message.timestamp);
        const timeStr = messageDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        
        messageElement.innerHTML = `
            <div class="message-content">${message.content.replace(/\n/g, '<br>')}</div>
            ${isOwn ? `
                <div class="message-actions">
                    <button class="delete-btn" onclick="deleteMessage('${message.id}')">🗑️</button>
                </div>
                <span class="status">${message.read ? '✓✓' : '✓'} ${timeStr}</span>
            ` : `<span class="status">${timeStr}</span>`}
        `;
        
        messagesList.appendChild(messageElement);
    });
    
    // Scroll to the bottom of the messages list
    messagesList.scrollTop = messagesList.scrollHeight;
}

function openChat(chatId, otherUser) {
    currentChat = chatId;
    document.querySelector('.welcome-screen').classList.add('hidden');
    document.querySelector('.active-chat').classList.remove('hidden');
    
    // For mobile view - show chat and hide sidebar
    if (window.innerWidth <= 768) {
        document.querySelector('.chat-container').classList.add('show-chat');
    }
    
    // Mark messages as read
    apiRequest('markAsRead', 'POST', { chatId });
    
    // Update chat header with other user's info
    displayChatHeader(otherUser);
    
    // Load messages
    loadMessages(chatId);
}

function displayChatHeader(otherUser) {
    document.querySelector('.chat-header').innerHTML = `
        <div class="chat-header-user">
            ${window.innerWidth <= 768 ? '<button class="back-button" onclick="backToChats(event)">←</button>' : ''}
            <img src="${otherUser.avatar}" alt="${otherUser.username}" class="avatar" onclick="showUserProfile('${otherUser.id}')">
            <div class="chat-header-info" onclick="showUserProfile('${otherUser.id}')">
                <div class="chat-header-name">${otherUser.name || otherUser.username}</div>
                <div class="chat-header-status" id="typing-indicator">Active</div>
            </div>
        </div>
        <div class="chat-header-actions">
            <button class="action-btn" onclick="showSearchModal()">🔍</button>
            <button class="action-btn" onclick="deleteChat('${currentChat}')">🗑️</button>
        </div>
    `;
}

function backToChats(event) {
    // Prevent event from bubbling up to parent elements
    if (event) {
        event.stopPropagation();
    }
    document.querySelector('.chat-container').classList.remove('show-chat');
}

function showUserProfile(userId) {
    // Fetch user data directly from API instead of relying on currentChat
    apiRequest('getUser', 'GET', { userId }).then(result => {
        if (result && result.success) {
            const userProfileModal = document.getElementById('userProfileModal');
            const user = result.user;
            
            userProfileModal.innerHTML = `
                <div class="modal-content">
                    <button class="close-btn" onclick="hideUserProfile()">×</button>
                    <div class="user-profile">
                        <img src="${user.avatar}" alt="${user.username}" class="large-avatar">
                        <h2>${user.username}</h2>
                        <p class="email">${user.email}</p>
                        <p class="bio">${user.bio || 'No bio available'}</p>
                        <p class="joined">Joined: ${new Date(user.created_at).toLocaleDateString()}</p>
                    </div>
                </div>
            `;
            userProfileModal.classList.remove('hidden');
        }
    });
}

function hideUserProfile() {
    document.getElementById('userProfileModal').classList.add('hidden');
}

function hideAddUserModal() {
    document.getElementById('addUserModal').classList.add('hidden');
    document.getElementById('userSearchInput').value = '';
    document.querySelector('.user-results').innerHTML = '';
}

async function deleteMessage(messageId) {
    if (!confirm('Are you sure you want to delete this message?')) {
        return;
    }
    
    const result = await apiRequest('deleteMessage', 'POST', { messageId });
    if (result && result.success) {
        // Reload messages after deletion
        loadMessages(currentChat);
    } else {
        alert('Failed to delete message');
    }
}

// Profile Management
function showEditProfileModal() {
    const editProfileModal = document.getElementById('editProfileModal');
    document.getElementById('editUsername').value = currentUser.username;
    document.getElementById('editBio').value = currentUser.bio || '';
    document.getElementById('edit-profile-error').style.display = 'none';
    editProfileModal.classList.remove('hidden');
}

function hideEditProfileModal() {
    document.getElementById('editProfileModal').classList.add('hidden');
}

async function updateProfile(username, bio) {
    const result = await apiRequest('updateProfile', 'POST', { username, bio });
    if (result && result.success) {
        currentUser = result.user;
        document.getElementById('userAvatar').src = currentUser.avatar;
        document.getElementById('userName').textContent = currentUser.username;
        hideEditProfileModal();
        
        // Reload the page to update all references to the user
        window.location.reload();
    } else {
        showError('edit-profile-error', result.error || 'Failed to update profile');
    }
}

// Polling
function startPolling() {
    stopPolling();
    pollingInterval = setInterval(async () => {
        if (currentChat) {
            await loadMessages(currentChat);
        }
        await loadChats();
        checkTypingStatus();
    }, 3000); // Poll every 3 seconds
}

function stopPolling() {
    if (pollingInterval) {
        clearInterval(pollingInterval);
        pollingInterval = null;
    }
}

// Send typing status
function sendTypingStatus(isTyping) {
    if (!currentChat) return;
    
    // Only send if status changed
    if (lastTypingStatus[currentChat] !== isTyping) {
        apiRequest('updateTypingStatus', 'POST', {
            chatId: currentChat,
            isTyping: isTyping
        });
        lastTypingStatus[currentChat] = isTyping;
    }
}

// Check typing status
function checkTypingStatus() {
    if (!currentChat) return;
    
    apiRequest('getTypingStatus', 'POST', { chatId: currentChat })
        .then(result => {
            if (result && result.success) {
                const typingIndicator = document.getElementById('typing-indicator');
                if (typingIndicator) {
                    if (result.isTyping && result.userId !== currentUser.id) {
                        typingIndicator.textContent = 'Typing...';
                        typingIndicator.classList.add('typing');
                    } else {
                        typingIndicator.textContent = 'Active';
                        typingIndicator.classList.remove('typing');
                    }
                }
            }
        })
        .catch(error => {
            console.error('Error checking typing status:', error);
        });
}

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    // Auth tabs
    document.getElementById('loginTab').addEventListener('click', () => {
        document.getElementById('loginTab').classList.add('active');
        document.getElementById('registerTab').classList.remove('active');
        document.getElementById('loginForm').classList.remove('hidden');
        document.getElementById('registerForm').classList.add('hidden');
    });

    document.getElementById('registerTab').addEventListener('click', () => {
        document.getElementById('registerTab').classList.add('active');
        document.getElementById('loginTab').classList.remove('active');
        document.getElementById('registerForm').classList.remove('hidden');
        document.getElementById('loginForm').classList.add('hidden');
    });

    // Login form
    document.getElementById('loginForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const username = document.getElementById('loginUsername').value;
        const password = document.getElementById('loginPassword').value;
        await login(username, password);
    });

    // Register form
    document.getElementById('registerForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        handleRegister(e);
    });

    // Logout button
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', logout);
    }

    // Add user button
    const addUserBtn = document.getElementById('addUserBtn');
    if (addUserBtn) {
        addUserBtn.addEventListener('click', () => {
            document.getElementById('addUserModal').classList.remove('hidden');
            document.getElementById('userSearchInput').focus();
        });
    }

    // Close modal buttons
    const closeModalBtn = document.getElementById('closeModalBtn');
    if (closeModalBtn) {
        closeModalBtn.addEventListener('click', hideAddUserModal);
    }

    // User search
    const userSearchInput = document.getElementById('userSearchInput');
    if (userSearchInput) {
        userSearchInput.addEventListener('input', () => {
            searchUsers(userSearchInput.value);
        });
    }

    // Message form
    const messageForm = document.getElementById('messageForm');
    const messageInput = document.getElementById('messageInput');
    
    if (messageForm && messageInput) {
        messageForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            if (!messageInput.value.trim()) return;
            
            const message = messageInput.value.trim();
            messageInput.value = '';
            
            // Reset textarea height
            messageInput.style.height = 'auto';
            
            if (currentChat) {
                const result = await apiRequest('sendMessage', 'POST', {
                    chatId: currentChat,
                    message
                });
                
                if (result && result.success) {
                    loadMessages(currentChat);
                }
            }
        });
        
        // Handle typing status
        messageInput.addEventListener('input', () => {
            if (messageInput.value.trim() && !isTyping) {
                isTyping = true;
                sendTypingStatus(true);
            } else if (!messageInput.value.trim() && isTyping) {
                isTyping = false;
                sendTypingStatus(false);
            }
            
            // Auto-resize textarea
            autoResizeTextarea(messageInput);
        });
        
        // Clear typing status when focus is lost
        messageInput.addEventListener('blur', () => {
            if (isTyping) {
                isTyping = false;
                sendTypingStatus(false);
            }
        });
    }

    // Edit profile button
    const editProfileBtn = document.getElementById('editProfileBtn');
    if (editProfileBtn) {
        editProfileBtn.addEventListener('click', showEditProfileModal);
    }

    // Close edit profile button
    const closeEditProfileBtn = document.getElementById('closeEditProfileBtn');
    if (closeEditProfileBtn) {
        closeEditProfileBtn.addEventListener('click', hideEditProfileModal);
    }

    // Edit profile form
    const editProfileForm = document.getElementById('editProfileForm');
    if (editProfileForm) {
        editProfileForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const username = document.getElementById('editUsername').value;
            const bio = document.getElementById('editBio').value;
            await updateProfile(username, bio);
        });
    }

    // Initialize the app
    initApp();
    
    // Set correct viewport height for mobile
    function setMobileViewportHeight() {
        // First we get the viewport height and multiply it by 1% to get a value for a vh unit
        let vh = window.innerHeight * 0.01;
        // Then we set the value in the --vh custom property to the root of the document
        document.documentElement.style.setProperty('--vh', `${vh}px`);
    }
    
    // Initial call to set viewport height
    setMobileViewportHeight();
    
    // Handle window resize for responsive layout
    window.addEventListener('resize', () => {
        // Update viewport height calculation on resize
        setMobileViewportHeight();
        
        // If we're on desktop width but active chat is showing
        const activeChat = document.querySelector('.active-chat');
        const chatContainer = document.querySelector('.chat-container');
        
        if (window.innerWidth > 768) {
            // On desktop, no need for show-chat class
            chatContainer.classList.remove('show-chat');
        } else if (!activeChat.classList.contains('hidden')) {
            // On mobile with active chat, ensure show-chat is active
            chatContainer.classList.add('show-chat');
        }
        
        // Refresh header to update back button visibility
        if (currentChat) {
            const otherUser = chatUsers[currentChat];
            if (otherUser) {
                displayChatHeader(otherUser);
            }
        }
    });
    
    // Also update on orientation change for mobile
    window.addEventListener('orientationchange', () => {
        // Small timeout to ensure the browser has completed the orientation change
        setTimeout(() => {
            setMobileViewportHeight();
        }, 100);
    });
});

// Auto resize textarea based on content
function autoResizeTextarea(textarea) {
    if (!textarea) return;
    
    textarea.style.height = 'auto';
    textarea.style.height = (textarea.scrollHeight) + 'px';
}

// Initialize App
function initApp() {
    apiRequest('checkAuth').then(result => {
        if (result && result.success) {
            currentUser = result.user;
            showChatInterface();
            loadChats();
            startPolling();
        } else {
            showAuthForms();
        }
    });
}

// Handle Form Submission
async function handleRegister(e) {
    e.preventDefault();
    
    const username = document.getElementById('registerUsername').value.trim();
    const name = document.getElementById('registerName').value.trim();
    const email = document.getElementById('registerEmail').value.trim();
    const password = document.getElementById('registerPassword').value;
    const errorElem = document.getElementById('register-error');
    
    if (!username || !email || !password || !name) {
        showError('register-error', 'All fields are required');
        return;
    }
    
    try {
        const result = await register(username, name, email, password);
        if (result && result.success) {
            // Registration successful
            document.getElementById('registerForm').reset();
        }
    } catch (error) {
        showError('register-error', 'An error occurred. Please try again.');
    }
}
