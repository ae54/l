<?php
session_start();
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: http://localhost:8000');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Credentials: true');

// Set error handling to prevent HTML errors
error_reporting(E_ALL);
ini_set('display_errors', 0);

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

class ChatAPI {
    private $usersFile = __DIR__ . '/data/users.json';
    private $chatsFile = __DIR__ . '/data/chats.json';
    private $messagesFile = __DIR__ . '/data/messages.json';
    private $typingStatusFile = __DIR__ . '/data/typing_status.json';

    public function __construct() {
        $this->initializeDataFiles();
        
        // Initialize typing status file if it doesn't exist
        if (!file_exists($this->typingStatusFile)) {
            file_put_contents($this->typingStatusFile, json_encode([]));
        }
    }

    private function initializeDataFiles() {
        // Create data directory if it doesn't exist
        $dataDir = __DIR__ . '/data';
        if (!is_dir($dataDir)) {
            mkdir($dataDir, 0777, true);
        }
        
        foreach ([$this->usersFile, $this->chatsFile, $this->messagesFile, $this->typingStatusFile] as $file) {
            if (!file_exists($file)) {
                file_put_contents($file, '[]');
            }
        }
    }

    private function readJsonFile($file) {
        $content = file_get_contents($file);
        if ($content === false) {
            throw new Exception("Failed to read file: $file");
        }
        $data = json_decode($content, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception("Invalid JSON in file: $file");
        }
        return $data;
    }

    private function writeJsonFile($file, $data) {
        $content = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        if ($content === false) {
            throw new Exception("Failed to encode JSON");
        }
        if (file_put_contents($file, $content) === false) {
            throw new Exception("Failed to write file: $file");
        }
    }

    public function register($data) {
        try {
            if (!isset($data['username']) || !isset($data['email']) || !isset($data['password'])) {
                return ['success' => false, 'error' => 'Missing required fields'];
            }

            $username = trim($data['username']);
            $name = isset($data['name']) ? trim($data['name']) : $username;
            $email = trim($data['email']);
            $password = $data['password'];

            if (strlen($username) < 3 || strlen($username) > 20) {
                return ['success' => false, 'error' => 'Username must be between 3 and 20 characters'];
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                return ['success' => false, 'error' => 'Invalid email format'];
            }

            if (strlen($password) < 6) {
                return ['success' => false, 'error' => 'Password must be at least 6 characters'];
            }

            $users = $this->readJsonFile($this->usersFile);
            
            if (array_filter($users, fn($u) => $u['username'] === $username)) {
                return ['success' => false, 'error' => 'Username already exists'];
            }

            if (array_filter($users, fn($u) => $u['email'] === $email)) {
                return ['success' => false, 'error' => 'Email already exists'];
            }

            $user = [
                'id' => uniqid(),
                'username' => $username,
                'name' => $name,
                'email' => $email,
                'password' => password_hash($password, PASSWORD_DEFAULT),
                'avatar' => "https://api.dicebear.com/7.x/avataaars/svg?seed=$username",
                'bio' => '',
                'created_at' => date('Y-m-d H:i:s')
            ];

            $users[] = $user;
            $this->writeJsonFile($this->usersFile, $users);

            $_SESSION['user'] = $user;
            unset($user['password']);

            return ['success' => true, 'user' => $user];
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    public function login($data) {
        try {
            if (!isset($data['username']) || !isset($data['password'])) {
                return ['success' => false, 'error' => 'Missing username or password'];
            }

            $username = trim($data['username']);
            $password = $data['password'];

            $users = $this->readJsonFile($this->usersFile);
            $user = array_filter($users, fn($u) => $u['username'] === $username);

            if (!$user) {
                return ['success' => false, 'error' => 'Invalid username or password'];
            }

            $user = reset($user);

            if (!password_verify($password, $user['password'])) {
                return ['success' => false, 'error' => 'Invalid username or password'];
            }

            $_SESSION['user'] = $user;
            unset($user['password']);

            return ['success' => true, 'user' => $user];
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    public function logout() {
        session_destroy();
        return ['success' => true];
    }

    public function checkAuth() {
        if (!isset($_SESSION['user'])) {
            return ['success' => false, 'error' => 'Not logged in'];
        }

        $user = $_SESSION['user'];
        unset($user['password']);
        return ['success' => true, 'user' => $user];
    }

    public function searchUsers($query) {
        try {
            if (!isset($_SESSION['user'])) {
                return ['success' => false, 'error' => 'Not logged in'];
            }

            if (!isset($query) || strlen($query) < 1) {
                return ['success' => false, 'error' => 'Search query too short'];
            }

            $users = $this->readJsonFile($this->usersFile);
            $currentUserId = $_SESSION['user']['id'];

            $results = array_filter($users, function($user) use ($query, $currentUserId) {
                return $user['id'] !== $currentUserId && 
                       stripos($user['username'], $query) !== false;
            });

            $results = array_map(function($user) {
                unset($user['password']);
                return $user;
            }, array_values($results));

            return ['success' => true, 'users' => $results];
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    public function createChat($data) {
        try {
            if (!isset($_SESSION['user'])) {
                return ['success' => false, 'error' => 'Not logged in'];
            }

            if (!isset($data['userId'])) {
                return ['success' => false, 'error' => 'User ID is required'];
            }

            $currentUserId = $_SESSION['user']['id'];
            $otherUserId = $data['userId'];

            if ($currentUserId === $otherUserId) {
                return ['success' => false, 'error' => 'Cannot chat with yourself'];
            }

            $chats = $this->readJsonFile($this->chatsFile);
            
            // Check if chat already exists
            foreach ($chats as $chat) {
                if (($chat['user1_id'] === $currentUserId && $chat['user2_id'] === $otherUserId) ||
                    ($chat['user1_id'] === $otherUserId && $chat['user2_id'] === $currentUserId)) {
                    return ['success' => true, 'chat' => $chat];
                }
            }

            // Create new chat
            $users = $this->readJsonFile($this->usersFile);
            $otherUser = array_filter($users, fn($u) => $u['id'] === $otherUserId);

            if (!$otherUser) {
                return ['success' => false, 'error' => 'User not found'];
            }

            $otherUser = reset($otherUser);
            unset($otherUser['password']);

            $chat = [
                'id' => uniqid(),
                'user1_id' => $currentUserId,
                'user2_id' => $otherUserId,
                'created_at' => date('Y-m-d H:i:s'),
                'user1' => $_SESSION['user'],
                'user2' => $otherUser
            ];

            unset($chat['user1']['password']);
            $chats[] = $chat;
            $this->writeJsonFile($this->chatsFile, $chats);

            return ['success' => true, 'chat' => $chat];
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    public function getChats() {
        try {
            if (!isset($_SESSION['user'])) {
                return ['success' => false, 'error' => 'Not logged in'];
            }

            $currentUserId = $_SESSION['user']['id'];
            $chats = $this->readJsonFile($this->chatsFile);

            $userChats = array_filter($chats, function($chat) use ($currentUserId) {
                return $chat['user1_id'] === $currentUserId || $chat['user2_id'] === $currentUserId;
            });

            return ['success' => true, 'chats' => array_values($userChats)];
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    public function getMessages($chatId) {
        try {
            if (!isset($_SESSION['user'])) {
                return ['success' => false, 'error' => 'Not logged in'];
            }

            if (!isset($chatId)) {
                return ['success' => false, 'error' => 'Chat ID is required'];
            }

            $currentUserId = $_SESSION['user']['id'];
            $chats = $this->readJsonFile($this->chatsFile);
            
            $chat = array_filter($chats, fn($c) => $c['id'] === $chatId);
            if (!$chat) {
                return ['success' => false, 'error' => 'Chat not found'];
            }
            
            $chat = reset($chat);
            if ($chat['user1_id'] !== $currentUserId && $chat['user2_id'] !== $currentUserId) {
                return ['success' => false, 'error' => 'Access denied'];
            }

            $messages = $this->readJsonFile($this->messagesFile);
            $chatMessages = array_filter($messages, fn($m) => $m['chatId'] === $chatId);
            $chatMessages = array_values($chatMessages);

            // Sort messages by timestamp
            usort($chatMessages, fn($a, $b) => strtotime($a['timestamp']) - strtotime($b['timestamp']));

            // Mark messages as read
            $messages = array_map(function($message) use ($currentUserId, $chatId) {
                if ($message['chatId'] === $chatId && $message['senderId'] !== $currentUserId) {
                    $message['read'] = true;
                }
                return $message;
            }, $messages);

            $this->writeJsonFile($this->messagesFile, $messages);

            return ['success' => true, 'messages' => $chatMessages];
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    public function sendMessage($data) {
        try {
            if (!isset($_SESSION['user'])) {
                return ['success' => false, 'error' => 'Not logged in'];
            }

            if (!isset($data['chatId']) || !isset($data['message']) || empty($data['message'])) {
                return ['success' => false, 'error' => 'Chat ID and content are required'];
            }

            $content = trim($data['message']);
            $currentUserId = $_SESSION['user']['id'];
            $chatId = $data['chatId'];

            $chats = $this->readJsonFile($this->chatsFile);
            $chat = array_filter($chats, fn($c) => $c['id'] === $chatId);

            if (!$chat) {
                return ['success' => false, 'error' => 'Chat not found'];
            }

            $chat = reset($chat);
            if ($chat['user1_id'] !== $currentUserId && $chat['user2_id'] !== $currentUserId) {
                return ['success' => false, 'error' => 'Access denied'];
            }

            $message = [
                'id' => uniqid(),
                'chatId' => $chatId,
                'senderId' => $currentUserId,
                'content' => $content,
                'timestamp' => date('Y-m-d H:i:s'),
                'read' => false
            ];

            $messages = $this->readJsonFile($this->messagesFile);
            $messages[] = $message;
            $this->writeJsonFile($this->messagesFile, $messages);

            return ['success' => true, 'message' => $message];
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    public function deleteMessage($messageId) {
        try {
            if (!isset($_SESSION['user'])) {
                return ['success' => false, 'error' => 'Not logged in'];
            }

            if (!isset($messageId)) {
                return ['success' => false, 'error' => 'Message ID is required'];
            }

            $currentUserId = $_SESSION['user']['id'];
            $messages = $this->readJsonFile($this->messagesFile);
            
            $message = array_filter($messages, fn($m) => $m['id'] === $messageId);
            if (!$message) {
                return ['success' => false, 'error' => 'Message not found'];
            }

            $message = reset($message);
            if ($message['senderId'] !== $currentUserId) {
                return ['success' => false, 'error' => 'Access denied'];
            }

            $messages = array_filter($messages, fn($m) => $m['id'] !== $messageId);
            $this->writeJsonFile($this->messagesFile, array_values($messages));

            return ['success' => true];
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    public function getUser($userId) {
        try {
            if (!isset($_SESSION['user'])) {
                return ['success' => false, 'error' => 'Not logged in'];
            }

            if (!isset($userId)) {
                return ['success' => false, 'error' => 'User ID is required'];
            }

            $users = $this->readJsonFile($this->usersFile);
            $user = array_filter($users, fn($u) => $u['id'] === $userId);

            if (!$user) {
                return ['success' => false, 'error' => 'User not found'];
            }

            $user = reset($user);
            unset($user['password']);  // Don't expose password hash

            return ['success' => true, 'user' => $user];
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    public function getAllMessages() {
        try {
            if (!isset($_SESSION['user'])) {
                return ['success' => false, 'error' => 'Not logged in'];
            }

            $currentUserId = $_SESSION['user']['id'];
            $chats = $this->readJsonFile($this->chatsFile);
            
            // Get all chats for the current user
            $userChats = array_filter($chats, function($chat) use ($currentUserId) {
                return $chat['user1_id'] === $currentUserId || $chat['user2_id'] === $currentUserId;
            });
            
            $userChatIds = array_map(function($chat) {
                return $chat['id'];
            }, array_values($userChats));
            
            // Get all messages for these chats
            $messages = $this->readJsonFile($this->messagesFile);
            $userMessages = array_filter($messages, function($message) use ($userChatIds) {
                return in_array($message['chatId'], $userChatIds);
            });

            return ['success' => true, 'messages' => array_values($userMessages)];
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    public function updateProfile($data) {
        try {
            if (!isset($_SESSION['user'])) {
                return ['success' => false, 'error' => 'Not logged in'];
            }

            $currentUserId = $_SESSION['user']['id'];
            $users = $this->readJsonFile($this->usersFile);
            
            $userIndex = -1;
            foreach ($users as $index => $user) {
                if ($user['id'] === $currentUserId) {
                    $userIndex = $index;
                    break;
                }
            }
            
            if ($userIndex === -1) {
                return ['success' => false, 'error' => 'User not found'];
            }
            
            // Update user fields
            if (isset($data['username'])) {
                $username = trim($data['username']);
                
                // Check if username is valid
                if (strlen($username) < 3 || strlen($username) > 20) {
                    return ['success' => false, 'error' => 'Username must be between 3 and 20 characters'];
                }
                
                // Check if username is already taken by another user
                foreach ($users as $user) {
                    if ($user['id'] !== $currentUserId && $user['username'] === $username) {
                        return ['success' => false, 'error' => 'Username already exists'];
                    }
                }
                
                $users[$userIndex]['username'] = $username;
                // Update avatar with new username
                $users[$userIndex]['avatar'] = "https://api.dicebear.com/7.x/avataaars/svg?seed=$username";
            }
            
            if (isset($data['bio'])) {
                $users[$userIndex]['bio'] = trim($data['bio']);
            }
            
            // Save updated users
            $this->writeJsonFile($this->usersFile, $users);
            
            // Update session
            $_SESSION['user'] = $users[$userIndex];
            
            // Return updated user
            $updatedUser = $users[$userIndex];
            unset($updatedUser['password']);
            
            return ['success' => true, 'user' => $updatedUser];
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    // Add/Update typing status
    public function updateTypingStatus($data) {
        try {
            if (!isset($_SESSION['user'])) {
                return ['success' => false, 'error' => 'Not logged in'];
            }

            if (!isset($data['chatId']) || !isset($data['isTyping'])) {
                return ['success' => false, 'error' => 'Chat ID and typing status are required'];
            }

            $chatId = $data['chatId'];
            $isTyping = (bool) $data['isTyping'];
            $userId = $_SESSION['user']['id'];

            $typingStatuses = [];
            if (file_exists($this->typingStatusFile)) {
                $typingStatuses = $this->readJsonFile($this->typingStatusFile);
            }

            if (!isset($typingStatuses[$chatId])) {
                $typingStatuses[$chatId] = [];
            }

            $typingStatuses[$chatId][$userId] = [
                'isTyping' => $isTyping,
                'timestamp' => time()
            ];

            // Clean up old statuses (older than 10 seconds)
            foreach ($typingStatuses as $chatKey => &$users) {
                foreach ($users as $userKey => $status) {
                    if (time() - $status['timestamp'] > 10) {
                        unset($users[$userKey]);
                    }
                }
                if (empty($users)) {
                    unset($typingStatuses[$chatKey]);
                }
            }

            $this->writeJsonFile($this->typingStatusFile, $typingStatuses);
            return ['success' => true];
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    // Get typing status for a chat
    public function getTypingStatus($data) {
        try {
            if (!isset($_SESSION['user'])) {
                return ['success' => false, 'error' => 'Not logged in'];
            }

            if (!isset($data['chatId'])) {
                return ['success' => false, 'error' => 'Chat ID is required'];
            }

            $chatId = $data['chatId'];
            $currentUserId = $_SESSION['user']['id'];
            
            $typingStatuses = [];
            if (file_exists($this->typingStatusFile)) {
                $typingStatuses = $this->readJsonFile($this->typingStatusFile);
            }
            
            $isTyping = false;
            $typingUserId = null;
            
            if (isset($typingStatuses[$chatId])) {
                foreach ($typingStatuses[$chatId] as $userId => $status) {
                    if ($userId !== $currentUserId && $status['isTyping'] && (time() - $status['timestamp'] < 5)) {
                        $isTyping = true;
                        $typingUserId = $userId;
                        break;
                    }
                }
            }
            
            return [
                'success' => true,
                'isTyping' => $isTyping,
                'userId' => $typingUserId
            ];
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
}

try {
    $api = new ChatAPI();
    $action = $_GET['action'] ?? '';
    $data = json_decode(file_get_contents('php://input'), true) ?? [];
    $response = null;

    switch ($action) {
        case 'register':
            $response = $api->register($data);
            break;
        case 'login':
            $response = $api->login($data);
            break;
        case 'logout':
            $response = $api->logout();
            break;
        case 'checkAuth':
            $response = $api->checkAuth();
            break;
        case 'searchUsers':
            $query = $_GET['query'] ?? '';
            $response = $api->searchUsers($query);
            break;
        case 'createChat':
            $response = $api->createChat($data);
            break;
        case 'getChats':
            $response = $api->getChats();
            break;
        case 'getMessages':
            $chatId = $_GET['chatId'] ?? '';
            $response = $api->getMessages($chatId);
            break;
        case 'sendMessage':
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $data = json_decode(file_get_contents('php://input'), true);
                
                if (!isset($data['chatId']) || !isset($data['message']) || empty($data['message'])) {
                    $response = ['success' => false, 'error' => 'Missing required parameters'];
                    break;
                }
                
                $chatId = $data['chatId'];
                $content = $data['message'];
                
                // Get the current user
                if (!isset($_SESSION['user'])) {
                    $response = ['success' => false, 'error' => 'User not authenticated'];
                    break;
                }
                
                $currentUser = $_SESSION['user'];
                
                // Generate a unique ID for the message
                $messageId = uniqid('', true);
                
                // Create a new message
                $message = [
                    'id' => $messageId,
                    'chatId' => $chatId,
                    'senderId' => $currentUser['id'],
                    'content' => $content, 
                    'timestamp' => date('Y-m-d H:i:s'),
                    'read' => false
                ];
                
                try {
                    // Load existing messages
                    $messagesFile = __DIR__ . '/data/messages.json';
                    $messages = json_decode(file_get_contents($messagesFile), true);
                    $messages[] = $message;
                    
                    // Save the updated messages
                    file_put_contents($messagesFile, json_encode($messages, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                    
                    $response = ['success' => true, 'message' => $message];
                } catch (Exception $e) {
                    $response = ['success' => false, 'error' => $e->getMessage()];
                }
                break;
            }
            $response = ['success' => false, 'error' => 'Invalid request method'];
            break;
        case 'deleteMessage':
            $messageId = isset($data['messageId']) ? $data['messageId'] : '';
            $response = $api->deleteMessage($messageId);
            break;
        case 'getUser':
            $userId = $_GET['userId'] ?? '';
            $response = $api->getUser($userId);
            break;
        case 'getAllMessages':
            $response = $api->getAllMessages();
            break;
        case 'updateProfile':
            $response = $api->updateProfile($data);
            break;
        case 'updateTypingStatus':
            $response = $api->updateTypingStatus($data);
            break;
        case 'getTypingStatus':
            $response = $api->getTypingStatus($data);
            break;
        default:
            $response = ['success' => false, 'error' => 'Invalid action'];
            break;
    }

    echo json_encode($response);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
